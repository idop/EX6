﻿using System.Windows.Forms;

namespace Ex06_UI
{
    public class Program
    {
        public static void Main()
        {
            FormGame game = new FormGame();
            game.ShowDialog();
        }
    }
}